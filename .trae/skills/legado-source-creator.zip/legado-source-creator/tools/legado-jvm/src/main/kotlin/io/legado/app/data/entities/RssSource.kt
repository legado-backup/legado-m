package io.legado.app.data.entities

import io.legado.app.constant.AppPattern
import io.legado.app.utils.splitNotBlank
import java.io.Serializable

// 简化说明：移除 Room 注解(@Entity/@PrimaryKey/@ColumnInfo/@Index)/Parcelable/@Parcelize/: BaseSource 继承/@JavascriptInterface，改为独立 Serializable POJO | 已知上限：失去 Room 持久化、Parcelable 高效序列化、BaseSource 的 77+ JS 扩展方法、WebView JS 注入接口 | 升级路径：需要 JS 执行时通过 AnalyzeRule 注入
data class RssSource(
    var sourceUrl: String = "",
    // 名称
    var sourceName: String = "",
    // 图标
    var sourceIcon: String = "",
    // 分组
    var sourceGroup: String? = null,
    // 注释
    var sourceComment: String? = null,
    // 是否启用
    var enabled: Boolean = true,
    // 自定义变量说明
    var variableComment: String? = null,
    // js库
    var jsLib: String? = null,
    // 启用okhttp CookieJAr 自动保存每次请求的cookie
    var enabledCookieJar: Boolean? = true,
    /**并发率**/
    var concurrentRate: String? = null,
    /**请求头**/
    var header: String? = null,
    /**登录地址**/
    var loginUrl: String? = null,
    /**登录Ui**/
    var loginUi: String? = null,
    /**登录检测js**/
    var loginCheckJs: String? = null,
    /**封面解密js**/
    var coverDecodeJs: String? = null,
    /**分类URL**/
    var sortUrl: String? = null,
    /**是否单url源**/
    var singleUrl: Boolean = false,
    /*列表规则*/
    /**列表样式,0,1,2,3,4**/
    var articleStyle: Int = 0,
    /**列表规则**/
    var ruleArticles: String? = null,
    /**下一页规则**/
    var ruleNextPage: String? = null,
    /**标题规则**/
    var ruleTitle: String? = null,
    /**发布日期规则**/
    var rulePubDate: String? = null,
    /*webView规则*/
    /**描述规则**/
    var ruleDescription: String? = null,
    /**图片规则**/
    var ruleImage: String? = null,
    /**链接规则**/
    var ruleLink: String? = null,
    /**正文规则**/
    var ruleContent: String? = null,
    /**正文url白名单**/
    var contentWhitelist: String? = null,
    /**正文url黑名单**/
    var contentBlacklist: String? = null,
    /**
     * 跳转url拦截,
     * js, 返回true拦截,js变量url,可以通过js打开url,比如调用阅读搜索,添加书架等,简化规则写法,不用webView js注入
     * **/
    var shouldOverrideUrlLoading: String? = null,
    /**webView样式**/
    var style: String? = null,
    var enableJs: Boolean = true,
    var loadWithBaseUrl: Boolean = true,
    /**注入js**/
    var injectJs: String? = null,
    /**提前预注入js**/
    var preloadJs: String? = null,
    /**web形式起始页**/
    var startHtml: String? = null,
    var startStyle: String? = null,
    var startJs: String? = null,
    /**是否输出web网页日志**/
    var showWebLog: Boolean = false,
    /*其它规则*/
    /**最后更新时间，用于排序**/
    var lastUpdateTime: Long = 0,
    var customOrder: Int = 0,
    /**类型 0网页，1图片，2视频**/
    var type: Int = 0,
    /**是否启用预加载**/
    var preload: Boolean = false,
    /**是否优先加载缓存**/
    var cacheFirst: Boolean = false,
    /**搜索url**/
    var searchUrl: String? = null
) : Serializable {

    fun getTag(): String {
        return sourceName
    }

    fun getKey(): String {
        return sourceUrl
    }

    override fun equals(other: Any?): Boolean {
        if (other is RssSource) {
            return other.sourceUrl == sourceUrl
        }
        return false
    }

    override fun hashCode() = sourceUrl.hashCode()

    fun equal(source: RssSource): Boolean {
        return equal(sourceUrl, source.sourceUrl)
                && equal(sourceName, source.sourceName)
                && equal(sourceIcon, source.sourceIcon)
                && enabled == source.enabled
                && equal(sourceGroup, source.sourceGroup)
                && enabledCookieJar == source.enabledCookieJar
                && equal(sourceComment, source.sourceComment)
                && equal(concurrentRate, source.concurrentRate)
                && equal(header, source.header)
                && equal(loginUrl, source.loginUrl)
                && equal(loginUi, source.loginUi)
                && equal(loginCheckJs, source.loginCheckJs)
                && equal(coverDecodeJs, source.coverDecodeJs)
                && equal(sortUrl, source.sortUrl)
                && singleUrl == source.singleUrl
                && articleStyle == source.articleStyle
                && equal(ruleArticles, source.ruleArticles)
                && equal(ruleNextPage, source.ruleNextPage)
                && equal(ruleTitle, source.ruleTitle)
                && equal(rulePubDate, source.rulePubDate)
                && equal(ruleDescription, source.ruleDescription)
                && equal(ruleLink, source.ruleLink)
                && equal(ruleContent, source.ruleContent)
                && enableJs == source.enableJs
                && loadWithBaseUrl == source.loadWithBaseUrl
                && equal(variableComment, source.variableComment)
                && equal(style, source.style)
                && equal(injectJs, source.injectJs)
                && equal(preloadJs, source.preloadJs)
                && equal(startHtml, source.startHtml)
                && equal(startStyle, source.startStyle)
                && equal(startJs, source.startJs)
                && showWebLog == source.showWebLog
                && type == source.type
                && preload == source.preload
                && cacheFirst == source.cacheFirst
                && equal(searchUrl, source.searchUrl)
    }

    private fun equal(a: String?, b: String?): Boolean {
        return a == b || (a.isNullOrEmpty() && b.isNullOrEmpty())
    }

    fun getDisplayNameGroup(): String {
        return if (sourceGroup.isNullOrBlank()) {
            sourceName
        } else {
            String.format("%s (%s)", sourceName, sourceGroup)
        }
    }

    fun addGroup(groups: String): RssSource {
        sourceGroup?.splitNotBlank(AppPattern.splitGroupRegex)?.toHashSet()?.let {
            it.addAll(groups.splitNotBlank(AppPattern.splitGroupRegex))
            sourceGroup = it.joinToString(",")
        }
        if (sourceGroup.isNullOrBlank()) sourceGroup = groups
        return this
    }

    fun removeGroup(groups: String): RssSource {
        sourceGroup?.splitNotBlank(AppPattern.splitGroupRegex)?.toHashSet()?.let {
            it.removeAll(groups.splitNotBlank(AppPattern.splitGroupRegex).toSet())
            sourceGroup = it.joinToString(",")
        }
        return this
    }

    fun getDisplayVariableComment(otherComment: String): String {
        return if (variableComment.isNullOrBlank()) {
            otherComment
        } else {
            "${variableComment}\n$otherComment"
        }
    }

}
